<template>
    <!-- 2020年3月10日10:01:50 可以冻结 -->
    <!-- 在现有的代码中：table+form的校验，会触发表格渲染两遍，所以把泡泡摘出来了 -->
    <Poptip
            v-model="showFlag"
            popper-class="ivu-table-popper "
            trigger="hover"
            placement="top" :transfer="true">
        <span :class="[prefixCls + '-freeze']">
            <y-icon type="loudou" ></y-icon>
        </span>
        <div slot="content" :class="[prefixCls + '-freeze-list']">
            <slot name="freezeContent"></slot>
        </div>
    </Poptip>
</template>
<script>
    import Poptip from '../poptip/poptip.vue';

    export default {
        components: { Poptip },
        props:{
            prefixCls: String,
            show:{
                type:Boolean
            },
            hide:{
                type:Boolean
            }

        },
        watch:{
            hide(newFlag, oldFlag){
                if(newFlag === false) {
                    this.showFlag = false;
                }
            }
        },
        data() {
            return {
                showFlag:this.show
            };
        },
        mounted() {
        },
        methods: {}
    }
</script>